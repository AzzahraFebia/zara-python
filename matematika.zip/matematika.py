# Konstanta pi
pi = 3.14

# Fungsi luas lingkaran 
def luas_lingkaran(jari_jari):
   return pi * (jari_jari ** 2)
     
# Fungsi luas persegi
def luas_persegi(sisi):
   return sisi * sisi